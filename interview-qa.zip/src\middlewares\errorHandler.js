module.exports = () => {
  return async (ctx, next) => {
    try {
      await next();
    } catch (err) {
      ctx.status = err.status || 500;
      ctx.body = {
        code: err.status || 500,
        message: err.message || '服务器内部错误'
      };
      
      // 记录错误日志
      console.error('Error:', err);
    }
  };
}; 