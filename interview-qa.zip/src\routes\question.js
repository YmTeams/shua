const Router = require('koa-router');
const router = new Router();

// 获取题目列表
router.get('/', async (ctx) => {
  // TODO: 实现获取题目列表逻辑
  ctx.body = {
    code: 0,
    data: {
      list: [],
      total: 0
    }
  };
});

// 获取题目详情
router.get('/:id', async (ctx) => {
  const { id } = ctx.params;
  // TODO: 实现获取题目详情逻辑
  ctx.body = {
    code: 0,
    data: {
      _id: id,
      title: '示例题目',
      content: '这是一道示例题目',
      type: 0,
      difficulty: 0,
      options: ['选项A', '选项B', '选项C', '选项D'],
      answer: [0],
      analysis: '这是答案解析'
    }
  };
});

// 提交答案
router.post('/answer', async (ctx) => {
  const { questionId, answer, timeSpent } = ctx.request.body;
  // TODO: 实现提交答案逻辑
  ctx.body = {
    code: 0,
    data: {
      isCorrect: true
    }
  };
});

// 收藏/取消收藏
router.post('/favorite', async (ctx) => {
  const { questionId, favorite } = ctx.request.body;
  // TODO: 实现收藏/取消收藏逻辑
  ctx.body = {
    code: 0,
    message: favorite ? '收藏成功' : '取消收藏成功'
  };
});

module.exports = router; 