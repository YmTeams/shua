# Ubuntu 服务器部署说明

## 1. 系统更新

```bash
# 更新系统包
sudo apt update
sudo apt upgrade -y

# 安装基础工具
sudo apt install -y curl git vim
```

## 2. 创建项目目录

```bash
sudo mkdir -p /www/interview-qa
sudo chown -R $USER:$USER /www/interview-qa
cd /www/interview-qa
```

## 3. 安装 Node.js

```bash
# 添加 NodeSource 仓库
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -

# 安装 Node.js
sudo apt install -y nodejs

# 验证安装
node --version
npm --version

# 安装 PM2
sudo npm install -g pm2
```

## 4. 安装 MySQL

```bash
# 安装 MySQL
sudo apt install -y mysql-server

# 启动 MySQL
sudo systemctl start mysql
sudo systemctl enable mysql

# 设置 root 密码
sudo mysql_secure_installation

# 创建数据库和用户
sudo mysql -u root -p
```

在 MySQL 提示符下执行：
```sql
CREATE DATABASE interview_qa CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'interview_qa'@'localhost' IDENTIFIED BY 'your_password_here';
GRANT ALL PRIVILEGES ON interview_qa.* TO 'interview_qa'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```

## 5. 安装 Redis（可选）

```bash
# 安装 Redis
sudo apt install -y redis-server

# 启动 Redis
sudo systemctl start redis-server
sudo systemctl enable redis-server

# 验证 Redis 运行状态
redis-cli ping
```

## 6. 配置 Nginx

```bash
# 安装 Nginx
sudo apt install -y nginx

# 启动 Nginx
sudo systemctl start nginx
sudo systemctl enable nginx

# 配置防火墙
sudo ufw allow 'Nginx Full'
sudo ufw allow ssh
sudo ufw enable
```

创建 Nginx 配置文件：
```bash
sudo vim /etc/nginx/sites-available/interview-qa
```

添加以下配置：
```nginx
server {
    listen 80;
    server_name 43.140.250.174;  # 替换为你的域名或IP

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

启用站点配置：
```bash
sudo ln -s /etc/nginx/sites-available/interview-qa /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

## 7. 部署项目

```bash
# 克隆项目
git clone [项目地址] .

# 安装依赖
cd server
npm install

# 配置环境变量
cp .env.production .env

# 编辑环境变量
vim .env

# 启动服务
pm2 start ecosystem.config.js --env production
```

## 8. 常用维护命令

```bash
# 查看应用状态
pm2 status

# 查看日志
pm2 logs

# 重启应用
pm2 restart interview-qa

# 停止应用
pm2 stop interview-qa

# 设置开机自启
pm2 startup
pm2 save

# 查看 MySQL 状态
sudo systemctl status mysql

# 查看 Redis 状态
sudo systemctl status redis

# 查看 Nginx 状态
sudo systemctl status nginx

# 查看错误日志
tail -f /www/interview-qa/logs/error.log
```

## 9. 备份说明

### 数据库备份
```bash
# 创建备份目录
mkdir -p /www/backup/mysql

# 备份数据库
mysqldump -u root -p interview_qa > /www/backup/mysql/interview_qa_$(date +%Y%m%d).sql

# 自动备份（添加到 crontab）
0 2 * * * mysqldump -u root -p'your_password' interview_qa > /www/backup/mysql/interview_qa_$(date +%Y%m%d).sql
```

### 日志轮转
```bash
# 安装 logrotate
sudo apt install -y logrotate

# 配置日志轮转
sudo vim /etc/logrotate.d/interview-qa
```

添加以下配置：
```
/www/interview-qa/logs/*.log {
    daily
    rotate 7
    compress
    delaycompress
    missingok
    notifempty
    create 644 root root
}
```

## 10. 监控和性能优化

### 系统监控
```bash
# 安装监控工具
pm2 install pm2-logrotate
pm2 install pm2-server-monit

# 查看监控面板
pm2 monit
```

### 性能优化
1. 确保 Node.js 内存限制合理设置
2. 开启 Nginx Gzip 压缩
3. 配置浏览器缓存
4. 使用 Redis 缓存热点数据
5. 定期清理日志和临时文件

## 11. 故障排查

### 常见问题处理
1. 应用无法启动
   ```bash
   # 检查日志
   pm2 logs
   # 检查端口占用
   sudo lsof -i :3000
   ```

2. 数据库连接失败
   ```bash
   # 检查 MySQL 状态
   sudo systemctl status mysql
   # 检查数据库连接
   mysql -u interview_qa -p -e "SELECT 1;"
   ```

3. Nginx 配置问题
   ```bash
   # 检查配置语法
   sudo nginx -t
   # 检查访问日志
   sudo tail -f /var/log/nginx/access.log
   # 检查错误日志
   sudo tail -f /var/log/nginx/error.log
   ``` 