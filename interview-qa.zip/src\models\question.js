const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Question = sequelize.define('Question', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  title: {
    type: DataTypes.STRING(255),
    allowNull: false
  },
  content: {
    type: DataTypes.TEXT,
    allowNull: false
  },
  type: {
    type: DataTypes.TINYINT,
    allowNull: false,
    validate: {
      isIn: [[0, 1, 2, 3]] // 0:单选 1:多选 2:判断 3:填空
    }
  },
  difficulty: {
    type: DataTypes.TINYINT,
    allowNull: false,
    validate: {
      isIn: [[0, 1, 2]] // 0:简单 1:中等 2:困难
    }
  },
  options: {
    type: DataTypes.JSON,
    allowNull: true
  },
  answer: {
    type: DataTypes.JSON,
    allowNull: false
  },
  analysis: {
    type: DataTypes.TEXT,
    allowNull: false
  },
  category_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'categories',
      key: 'id'
    }
  },
  tags: {
    type: DataTypes.JSON,
    defaultValue: []
  },
  answer_count: {
    type: DataTypes.INTEGER,
    defaultValue: 0
  },
  correct_count: {
    type: DataTypes.INTEGER,
    defaultValue: 0
  },
  favorite_count: {
    type: DataTypes.INTEGER,
    defaultValue: 0
  }
}, {
  tableName: 'questions',
  indexes: [
    {
      fields: ['category_id']
    },
    {
      fields: ['type']
    },
    {
      fields: ['difficulty']
    }
  ]
});

module.exports = Question; 