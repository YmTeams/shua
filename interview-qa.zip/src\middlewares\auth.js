const jwt = require('jsonwebtoken');
const User = require('../models/user');

module.exports = (options = {}) => {
  return async (ctx, next) => {
    try {
      // 获取token
      const token = ctx.headers.authorization?.split(' ')[1];
      
      if (!token && !options.optional) {
        ctx.throw(401, '请先登录');
      }

      if (token) {
        // 验证token
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        
        // 查询用户
        const user = await User.findByPk(decoded.id);
        
        if (!user) {
          ctx.throw(401, '用户不存在');
        }

        // 检查会员权限
        if (options.requirePaid && !user.is_paid) {
          ctx.throw(403, '需要付费会员才能访问');
        }

        // 将用户信息添加到上下文
        ctx.state.user = user;
      }

      await next();
    } catch (err) {
      if (err.name === 'TokenExpiredError') {
        ctx.throw(401, 'token已过期');
      } else if (err.name === 'JsonWebTokenError') {
        ctx.throw(401, 'token无效');
      } else {
        throw err;
      }
    }
  };
}; 