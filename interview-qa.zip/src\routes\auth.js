const Router = require('koa-router');
const router = new Router();

// 发送验证码
router.post('/send-code', async (ctx) => {
  const { phone } = ctx.request.body;
  // TODO: 实现验证码发送逻辑
  ctx.body = {
    code: 0,
    message: '发送成功'
  };
});

// 登录
router.post('/login', async (ctx) => {
  const { phone, code } = ctx.request.body;
  // TODO: 实现登录逻辑
  ctx.body = {
    code: 0,
    message: '登录成功',
    data: {
      token: 'mock_token',
      userInfo: {
        phone,
        nickname: '用户' + phone.substr(-4),
        avatar: '',
        isPaid: false
      }
    }
  };
});

module.exports = router; 