module.exports = {
  apps: [{
    name: 'interview-qa',
    script: 'src/app.js',
    instances: 2,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    env_production: {
      NODE_ENV: 'production',
      PORT: 3000
    },
    log_date_format: 'YYYY-MM-DD HH:mm:ss',
    error_file: '/www/interview-qa/logs/error.log',
    out_file: '/www/interview-qa/logs/out.log',
    merge_logs: true,
    log_type: 'json'
  }]
}; 