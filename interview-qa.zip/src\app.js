require('dotenv').config();
const Koa = require('koa');
const cors = require('koa-cors');
const bodyParser = require('koa-bodyparser');
const errorHandler = require('./middlewares/error-handler');

const app = new Koa();

// 错误处理
app.use(errorHandler);

// 跨域处理
app.use(cors());

// 请求体解析
app.use(bodyParser());

// 路由
// TODO: 添加路由

// 数据库连接
const sequelize = require('./config/database');
sequelize.authenticate()
  .then(() => {
    console.log('数据库连接成功');
    // 同步数据库模型
    return sequelize.sync({ alter: process.env.NODE_ENV === 'development' });
  })
  .then(() => {
    console.log('数据库模型同步完成');
  })
  .catch(err => {
    console.error('数据库连接失败:', err);
  });

const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`服务器运行在 http://localhost:${port}`);
}); 