module.exports = async (ctx, next) => {
  try {
    await next();
  } catch (err) {
    // 开发环境下打印错误堆栈
    if (process.env.NODE_ENV === 'development') {
      console.error(err);
    }

    ctx.status = err.status || 500;
    ctx.body = {
      code: err.status || 500,
      message: err.message || '服务器内部错误'
    };

    // 处理特定类型的错误
    if (err.name === 'SequelizeValidationError') {
      ctx.status = 400;
      ctx.body.message = err.errors[0].message;
    } else if (err.name === 'SequelizeUniqueConstraintError') {
      ctx.status = 400;
      ctx.body.message = '数据已存在';
    }

    // 触发应用级错误事件
    ctx.app.emit('error', err, ctx);
  }
}; 