const Router = require('koa-router');
const router = new Router();

// 获取分类列表
router.get('/', async (ctx) => {
  // TODO: 实现获取分类列表逻辑
  ctx.body = {
    code: 0,
    data: [
      {
        _id: '1',
        name: 'JavaScript',
        icon: '',
        description: 'JavaScript相关题目',
        questionCount: 100
      },
      {
        _id: '2',
        name: 'HTML/CSS',
        icon: '',
        description: 'HTML/CSS相关题目',
        questionCount: 80
      },
      {
        _id: '3',
        name: 'Vue',
        icon: '',
        description: 'Vue相关题目',
        questionCount: 60
      },
      {
        _id: '4',
        name: 'React',
        icon: '',
        description: 'React相关题目',
        questionCount: 50
      }
    ]
  };
});

module.exports = router; 