# Ubuntu 服务器部署说明

## 1. 环境要求

- Node.js 14.0.0+
- MySQL 5.7+
- Redis (可选，用于验证码存储)
- PM2 (进程管理)

## 2. 部署步骤

### 2.1 更新系统包
```bash
sudo apt update
sudo apt upgrade
```

### 2.2 安装 Node.js
```bash
# 安装 curl
sudo apt install -y curl

# 安装 nvm
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.0/install.sh | bash
source ~/.bashrc

# 安装 Node.js
nvm install 14
nvm use 14

# 验证安装
node --version
npm --version
```

### 2.3 安装 MySQL
```bash
# 安装 MySQL
sudo apt install -y mysql-server

# 启动 MySQL
sudo systemctl start mysql
sudo systemctl enable mysql

# 设置 MySQL 安全配置
sudo mysql_secure_installation

# 登录 MySQL（首次登录无需密码）
sudo mysql
```

在 MySQL 中执行以下命令设置 root 密码：
```sql
ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY 'your_password_here';
FLUSH PRIVILEGES;
exit;
```

### 2.4 安装 Redis (可选)
```bash
# 安装 Redis
sudo apt install -y redis-server

# 启动 Redis
sudo systemctl start redis-server
sudo systemctl enable redis-server

# 验证 Redis 运行状态
sudo systemctl status redis-server
```

### 2.5 安装 PM2
```bash
# 安装 PM2
sudo npm install -g pm2
```

### 2.6 部署项目

1. 创建项目目录：
```bash
sudo mkdir -p /www/interview-qa
sudo chown -R $USER:$USER /www/interview-qa
cd /www/interview-qa
```

2. 上传项目文件到服务器：
```bash
# 在本地执行
scp -r ./server/* root@43.140.250.174:/www/interview-qa/
```

3. 安装依赖：
```bash
cd /www/interview-qa
npm install
```

4. 创建并配置环境变量：
```bash
cp .env.production .env
vim .env
```

5. 创建数据库：
```sql
CREATE DATABASE interview_qa CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

6. 创建日志目录：
```bash
mkdir -p /www/interview-qa/logs
```

7. 使用 PM2 启动服务：
```bash
pm2 start ecosystem.config.js --env production
```

### 2.7 安装和配置 Nginx

1. 安装 Nginx：
```bash
sudo apt install -y nginx
```

2. 创建 Nginx 配置文件：
```bash
sudo vim /etc/nginx/sites-available/interview-qa
```

添加以下配置：
```nginx
server {
    listen 80;
    server_name 43.140.250.174;  # 替换为你的域名

    location /api {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
}
```

3. 启用站点配置：
```bash
sudo ln -s /etc/nginx/sites-available/interview-qa /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default  # 删除默认配置
```

4. 测试并重启 Nginx：
```bash
sudo nginx -t
sudo systemctl restart nginx
```

### 2.8 配置防火墙

```bash
# 安装 UFW
sudo apt install -y ufw

# 配置防火墙规则
sudo ufw allow ssh
sudo ufw allow http
sudo ufw allow https
sudo ufw allow 3000

# 启用防火墙
sudo ufw enable

# 查看状态
sudo ufw status
```

## 3. 常用命令

### 3.1 PM2 命令
```bash
# 启动服务
pm2 start ecosystem.config.js --env production

# 重启服务
pm2 restart interview-qa

# 停止服务
pm2 stop interview-qa

# 查看日志
pm2 logs interview-qa

# 查看状态
pm2 status

# 开机自启
pm2 startup ubuntu
```

### 3.2 MySQL 命令
```bash
# 登录 MySQL
mysql -u root -p

# 备份数据库
mysqldump -u root -p interview_qa > backup.sql

# 恢复数据库
mysql -u root -p interview_qa < backup.sql
```

### 3.3 Redis 命令
```bash
# 登录 Redis
redis-cli

# 查看状态
redis-cli ping
```

## 4. 注意事项

1. 安全配置：
   - 使用 UFW 配置防火墙
   - 修改 SSH 默认端口（可选）
   - 禁用 root 远程登录
   - 设置强密码
   - 定期更新系统：`sudo apt update && sudo apt upgrade`

2. 备份策略：
   - 配置定时备份数据库：
     ```bash
     # 编辑定时任务
     crontab -e
     
     # 添加每天凌晨3点备份
     0 3 * * * mysqldump -u root -p'your_password' interview_qa > /backup/interview_qa_$(date +\%Y\%m\%d).sql
     ```

3. 监控：
   - 安装监控工具：
     ```bash
     sudo apt install -y htop
     sudo apt install -y netstat
     ```

4. 性能优化：
   - 配置 Nginx 缓存
   - 优化 MySQL 配置
   - 配置 Node.js 内存限制

## 5. 故障排查

1. 查看应用日志：
```bash
pm2 logs interview-qa
```

2. 查看 Nginx 日志：
```bash
sudo tail -f /var/log/nginx/error.log
sudo tail -f /var/log/nginx/access.log
```

3. 查看 MySQL 日志：
```bash
sudo tail -f /var/log/mysql/error.log
```

4. 查看系统日志：
```bash
sudo journalctl -u mysql
sudo journalctl -u nginx
sudo journalctl -u redis-server
``` 