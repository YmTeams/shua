const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const AnswerRecord = sequelize.define('AnswerRecord', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  user_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'users',
      key: 'id'
    }
  },
  question_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'questions',
      key: 'id'
    }
  },
  answer: {
    type: DataTypes.JSON,
    allowNull: false
  },
  is_correct: {
    type: DataTypes.BOOLEAN,
    allowNull: false
  },
  time_spent: {
    type: DataTypes.INTEGER,
    allowNull: false,
    comment: '答题用时（秒）'
  }
}, {
  tableName: 'answer_records',
  indexes: [
    {
      fields: ['user_id']
    },
    {
      fields: ['question_id']
    },
    {
      fields: ['created_at']
    }
  ]
});

module.exports = AnswerRecord; 