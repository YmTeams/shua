const Router = require('koa-router');
const authRoutes = require('./auth');
const userRoutes = require('./user');
const questionRoutes = require('./question');
const categoryRoutes = require('./category');

const router = new Router({
  prefix: '/api/v1'
});

// 注册子路由
router.use('/auth', authRoutes.routes());
router.use('/user', userRoutes.routes());
router.use('/questions', questionRoutes.routes());
router.use('/categories', categoryRoutes.routes());

module.exports = router; 