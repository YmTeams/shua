const Router = require('koa-router');
const router = new Router();

// 获取用户信息
router.get('/info', async (ctx) => {
  // TODO: 实现获取用户信息逻辑
  ctx.body = {
    code: 0,
    data: {
      phone: '13800138000',
      nickname: '测试用户',
      avatar: '',
      isPaid: false
    }
  };
});

// 获取用户统计信息
router.get('/statistics', async (ctx) => {
  // TODO: 实现获取统计信息逻辑
  ctx.body = {
    code: 0,
    data: {
      totalQuestions: 100,
      correctCount: 80,
      correctRate: 80,
      totalTime: 120,
      averageTime: 72,
      continuousDays: 5
    }
  };
});

module.exports = router; 